package gui;

public enum MoveDirection {
	NORTH, EAST, SOUTH, WEST;
}
