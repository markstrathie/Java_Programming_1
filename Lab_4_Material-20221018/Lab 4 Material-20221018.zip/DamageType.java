public enum DamageType {
	FIRE,WATER,PLANT,NORMAL
}
